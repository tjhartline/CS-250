
    /**
	 * Tammy Hartline: 
	 * Developer notes: Altered background color, foreground color, layout, and border.
	 * 01/20/2023
	 */


import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
            	topDestinationListFrame.setTitle("Top 5 Destinations List"); //added 's' to destination for proper grammar
            	topDestinationListFrame.pack(); 
            	topDestinationListFrame.setVisible(true);
               
                
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private DefaultListModel<TextAndIcon> listModel;

    @SuppressWarnings("unchecked")
	public TopDestinationListFrame() {
        super("Top Five Destination's List");	//added 's' for proper grammar
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);
    	
        listModel = new DefaultListModel<TextAndIcon>();
              
        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("   1. New Zealand (Majestic & dramatic terrain with spectacular fjords.)", new ImageIcon(getClass().getResource("/resources/640px-New_Zealand_South_Island_North_Coast.jpg")));
        //Top destination South Island, New Zealand
        addDestinationNameAndPicture("   2. Paris (The Eiffel Tower, Louvre, Arc de Triomphe, Romantic Getaway.)", new ImageIcon(getClass().getResource("/resources/640px-Eiffel_Tower_and_Seine_River.jpg")));
        //2nd top destination Paris
        addDestinationNameAndPicture("   3. Bora Bora (Tropical island with picturesque beaches & lush jungles.)", new ImageIcon(getClass().getResource("/resources/Bora-Bora_French_Polynesia_-_panoramio_(40).jpg")));
        //3rd top destination BoraBora
        addDestinationNameAndPicture("   4. Maui (Lush coastline with white or black sand Hawaiian paradise.)", new ImageIcon(getClass().getResource("/resources/Starr-200803-7978-Scaevola_taccada-lava_lined_coast_view_West_Maui-Wailea_Coastal_Walk-Maui_(50338013976).jpg")));
        //4th top destination Maui
        addDestinationNameAndPicture("   5. Tahiti (Relax, snorkel, surf and enjoy this lavish tropical paradise.)", new ImageIcon(getClass().getResource("/resources/640px-Destinos_turisticos_de_Tahití.jpg")));
        //5th top destination Tahiti
        
        JList<TextAndIcon> list = new JList<TextAndIcon>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
        
        list.setBackground(Color.BLACK);	//changed color to meet rubric requirements.
        list.setForeground(Color.WHITE);	//changed color for visibility reasons.
        list.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.WHITE));	//set border color.
        
        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(100);	//changed to 100 for better alignment

        list.setCellRenderer(renderer);

        getContentPane().add(scrollPane, BorderLayout.CENTER);	
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
        
        
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Border NO_FOCUS_BORDER = new EmptyBorder(1,1,1,1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(1,1,1,1);
        this.setBorder(getBorder());;
    }

    public TextAndIconListCellRenderer(int padding) {	//changed to make more visually appealing
        this.insideBorder = BorderFactory.createEmptyBorder(padding,padding,padding,padding);
        Border outline;
        outline = BorderFactory.createDashedBorder(Color.WHITE);
        setBorder(outline);
        setOpaque(true);
    }

    public TextAndIconListCellRenderer(int toppadding, int bottompadding, int leftpadding, int rightpadding) {	//changed to make more visually appealing
        
        insideBorder = BorderFactory.createEmptyBorder();
        setBorder(insideBorder);
        
        setOpaque(true);	//had changed to false, but selection is more distinguishable when true.
    }
    
    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
        	
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;
        outsideBorder = BorderFactory.createBevelBorder(VERTICAL,Color.WHITE, Color.WHITE);
        outsideBorder.getBorderInsets(list);
        setBorder(outsideBorder);

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}